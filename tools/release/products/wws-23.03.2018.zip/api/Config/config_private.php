<?php
/**
 * Created by PhpStorm.
 * User: benying.zou
 * Date: 15.12.2016
 * Time: 10:04
 */

$config['system']['name'] = 'Wiewind Studio';

$config['system']['domain'] = $_SERVER['HTTP_HOST'];
$config['system']['path'] = 'apps/workshop1';
$config['system']['app']['dirname'] = 'WWS';


$config['system']['filemanagement']['dirname'] = '../../workshop/webroot/fmroot';
$config['system']['jobattachment']['root']  = '../../workshop/webroot/jobattachment';