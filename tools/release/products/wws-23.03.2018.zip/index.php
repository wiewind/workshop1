<?php
header('Location: WWS/index.php');
?>